<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset='utf-8'>
	<link rel='stylesheet' type='text/css' href='css/style.css'>
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600&family=Roboto+Condensed&display=swap" rel="stylesheet">
</head>
<body>
	<div class="survey-request">
		<form class="form-view" onsubmit="return false;" >
			<input class="survey-request__button request-cell" type="submit" value="Получить данные">
		</form>
	</div>

	<script src="script/viewUsers.js"></script>
</body>
</html>
<!-- 2 задание -->