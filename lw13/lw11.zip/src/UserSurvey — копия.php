<?php

function getPostParameter(string $name): ?string //тип возращаемого значения, ? - null
{
    return isset($_POST[$name]) ? $_POST[$name] : null; //isset - T/F, если ключ найдем, то правда, а если нет то нуль
}

$firstName = getPostParameter('first_name'); // переменным присваиваем занчения из ссылки 
$email = getPostParameter('email');
$activity = getPostParameter('activity');
$agreement = getPostParameter('agreement'); // считывание chekboxa 


if (empty($email)) 
{
	echo "Почта не указана";
	exit();
}

$file = "../data/" . $email . ".txt"; // путь до файла 

if (file_exists($file)) // существует ли файл, его перезапись, и мы сохраняем то, что записали
{
	$tempArray = file($file); // временный массив, разбивает внутренности файла на массив построчно 
	if (!(empty($firstName)))
	{
		$tempArray[0] = "First Name: $firstName\n";
	}

	if (!(empty($activity)))
	{
		$tempArray[2] = "Activity: $activity";
	}

	file_put_contents($file, $tempArray); // запись данных  в файл, через запятую все элементы ,и массив сохраняем в файл
} 
else
{
	$userTxt = fopen($file, "w"); 
	fwrite($userTxt, "First Name: $firstName\n"); // записывает содержание строк в $userTxt
	fwrite($userTxt, "Email: $email\n");
	fwrite($userTxt, "Activity: $activity");
	fclose($userTxt); // закрытие открытого файла 
}

header("Refresh: 0; url = /src/request.php"); // перессылка на получение данных
?>

<!-- 2 -->